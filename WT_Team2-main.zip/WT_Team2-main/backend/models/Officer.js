const mongoose = require('mongoose');

const OfficerSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    dept: { type: String, required: true },
    active: { type: Number, default: 0 },
    resolved: { type: Number, default: 0 },
    score: { type: Number, default: 100 },
    status: { type: String, default: 'Active' }
});

module.exports = mongoose.model('Officer', OfficerSchema);

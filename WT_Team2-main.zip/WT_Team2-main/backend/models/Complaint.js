const mongoose = require('mongoose');

const ComplaintSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    name: { type: String, required: true },
    desc: { type: String, default: "" },
    dept: { type: String, default: "General" },
    type: { type: String, default: "General" },
    priority: { type: String, default: "Medium" },
    status: { type: String, default: "Pending" },
    officer: { type: String, default: "" },
    evidence: { type: String, default: "" },
    date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Complaint', ComplaintSchema);

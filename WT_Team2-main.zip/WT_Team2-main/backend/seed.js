require('dotenv').config();
const mongoose = require('mongoose');
const Complaint = require('./models/Complaint');
const Officer = require('./models/Officer');

const complaintsData = [
    { id: "CMP-1001", title: "Pothole on Main St", name: "Citizen User", desc: "Big pothole", dept: "Roads", priority: "High", status: "Pending", officer: "John Doe", date: "2026-03-01" },
    { id: "CMP-1002", title: "Water Leakage in Sector 4", name: "Citizen User", desc: "Pipe bursting", dept: "Water Supply", priority: "Medium", status: "Resolved", officer: "Jane Smith", date: "2026-03-02" },
    { id: "CMP-1003", title: "Street Light Not Working", name: "Citizen User", desc: "No light", dept: "Electricity", priority: "Low", status: "In Progress", officer: "Mike Ross", date: "2026-03-03" },
    { id: "CMP-1004", title: "Garbage Collection Delayed", name: "Citizen User", desc: "Garbage not collected", dept: "Sanitation", priority: "Medium", status: "Pending", officer: "Sarah Connor", date: "2026-03-04" },
    { id: "CMP-1005", title: "Traffic Signal Malfunction", name: "Citizen User", desc: "Signal broken", dept: "Public Safety", priority: "High", status: "In Progress", officer: "James Bond", date: "2026-03-05" }
];

const officersData = [
    { id: "OFF-201", name: "John Doe", dept: "Roads", active: 2, resolved: 15, score: 88, status: "Active" },
    { id: "OFF-202", name: "Jane Smith", dept: "Water Supply", active: 3, resolved: 12, score: 92, status: "Active" },
    { id: "OFF-203", name: "Mike Ross", dept: "Electricity", active: 2, resolved: 10, score: 85, status: "Active" },
    { id: "OFF-204", name: "Sarah Connor", dept: "Sanitation", active: 4, resolved: 8, score: 78, status: "Active" },
    { id: "OFF-205", name: "James Bond", dept: "Public Safety", active: 1, resolved: 20, score: 95, status: "Active" }
];

mongoose.connect(process.env.MONGODB_URI).then(async () => {
    console.log('MongoDB Connected. Seeding data...');
    
    // Clear existing data
    await Complaint.deleteMany({});
    await Officer.deleteMany({});
    
    console.log('Cleared existing data.');
    
    // Insert new data
    await Complaint.insertMany(complaintsData);
    await Officer.insertMany(officersData);
    
    console.log('Database seeded successfully!');
    process.exit(0);
}).catch(err => {
    console.error('Error seeding data:', err);
    process.exit(1);
});

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const Complaint = require('./models/Complaint');
const Officer = require('./models/Officer');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Multer Config
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log('MongoDB Connection Error:', err));

// --- Routes ---

// Health Check
app.get('/api/health', (req, res) => {
    res.json({ status: "Server is running perfectly!" });
});

// Get all complaints
app.get('/api/complaints', async (req, res) => {
    try {
        const complaints = await Complaint.find().sort({ date: -1 });
        res.json(complaints);
    } catch(err) {
        res.status(500).json({ error: 'Server error' });
    }
});

// File a new complaint
app.post('/api/complaints', upload.single('evidence'), async (req, res) => {
    try {
        const { name, category, title, desc } = req.body;
        
        const randomNum = Math.floor(100000 + Math.random() * 900000);
        const genId = "CMP" + randomNum;
        
        // Auto-assign department based on category rough mapping
        let dept = "General";
        if(category === "Road Damage") dept = "Roads";
        if(category === "Water Issue") dept = "Water Supply";
        if(category === "Electricity Issue" || category === "Cyber Crime") dept = "Electricity";
        if(category === "Garbage Issue") dept = "Sanitation";
        if(category === "Public Safety") dept = "Public Safety";

        const newComplaint = new Complaint({
            id: genId,
            title: title || category,
            name: name || "Anonymous",
            desc: desc || "",
            dept: dept,
            type: category || "General",
            priority: "Medium",
            status: "Pending",
            officer: "",
            evidence: req.file ? req.file.path : "",
            date: new Date().toLocaleDateString()
        });
        
        await newComplaint.save();
        res.status(201).json(newComplaint);
    } catch(err) {
        res.status(500).json({ error: 'Server error' });
    }
});

// Update complaint
app.put('/api/complaints/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const { status, officer, priority } = req.body;
        
        const updateData = {};
        if(status) updateData.status = status;
        if(officer !== undefined) updateData.officer = officer;
        if(priority) updateData.priority = priority;
        
        const updatedComplaint = await Complaint.findOneAndUpdate(
            { id: id },
            { $set: updateData },
            { new: true }
        );
        
        if(!updatedComplaint) return res.status(404).json({ error: "Complaint not found" });
        res.json(updatedComplaint);
    } catch(err) {
        res.status(500).json({ error: 'Server error' });
    }
});

// Get officers
app.get('/api/officers', async (req, res) => {
    try {
        const officers = await Officer.find();
        res.json(officers);
    } catch(err) {
        res.status(500).json({ error: 'Server error' });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`Citizen Portal Backend running on http://localhost:${PORT}`);
});

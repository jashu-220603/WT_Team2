/**
 * Dashboard Logic for Citizen Complaint Management System
 */

// Mock Data
const departments = ["All Departments", "Roads", "Water Supply", "Electricity", "Sanitation", "Public Safety"];

let complaintsData = [];
let officersData = [];

const activityLog = [
    { text: "System Boot: CMS Admin Dashboard initialized.", time: "1 min ago" },
    { text: "Officer John Doe assigned to high-priority case CMP-1001 (Pothole on Main St)", time: "5 mins ago" },
    { text: "System Data Sync: department workloads updated.", time: "15 mins ago" },
    { text: "Officer Jane Smith successfully resolved CMP-1002 (Water Leakage)", time: "1 hour ago" },
    { text: "Admin reviewed weekly performance Analytics report", time: "2 hours ago" },
    { text: "Admin reassigned CMP-1005 (Traffic Signal Malfunction) to James Bond due to priority change", time: "3 hours ago" },
    { text: "Automated alert: 3 new complaints received in 'Roads' department", time: "4 hours ago" },
    { text: "Daily backup completed successfully", time: "1 day ago" }
];

const notifications = [
    { id: 1, text: "Officer John Doe assigned to CMP-1001", time: "5 mins ago", icon: "user-plus", color: "primary" },
    { id: 2, text: "Complaint CMP-1002 status updated to Resolved", time: "1 hour ago", icon: "check-circle", color: "success" },
    { id: 3, text: "New complaint submitted: CMP-1010", time: "2 hours ago", icon: "plus-circle", color: "info" }
];

// State
let currentDepartment = "All Departments";
let searchTerm = "";
let statusFilter = "All";
let priorityFilter = "All";
let officerFilter = "All";
let charts = {};

// placeholder admin name (would come from backend)
const adminName = "Admin User";

// Initialize Dashboard
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const cRes = await fetch('http://localhost:5000/api/complaints');
        complaintsData = await cRes.json();
        
        const oRes = await fetch('http://localhost:5000/api/officers');
        officersData = await oRes.json();
    } catch(err) {
        console.error("Failed to fetch initial admin data", err);
    }

    initSidebar();
    initDepartmentSelector();
    initNotifications();
    initCharts();
    initOfficerFilter();
    renderTable();
    renderDepartmentInfo();
    renderAssignmentTable();
    renderOfficersTable();
    renderWorkload();
    renderActivityLog();
    renderDepartmentsTable();
    updateStats();
    initModalHandlers();

    // set greeting name
    const greetEl = document.getElementById('admin-greeting');
    if (greetEl) greetEl.innerText = `Hello, ${adminName}`;
    updateGreetingSubtitle();

    const hash = window.location.hash.replace('#', '');
    if (hash && hash.endsWith('-section')) {
        const sectionName = hash.replace('-section', '');
        switchSection(sectionName);
    }

    document.getElementById('search-box').addEventListener('input', (e) => {
        searchTerm = e.target.value.toLowerCase();
        renderTable();
    });

    document.getElementById('status-filter').addEventListener('change', (e) => {
        statusFilter = e.target.value;
        renderTable();
    });

    document.getElementById('priority-filter').addEventListener('change', (e) => {
        priorityFilter = e.target.value;
        renderTable();
    });

    document.getElementById('officer-filter').addEventListener('change', (e) => {
        officerFilter = e.target.value;
        renderTable();
    });
});

// Sidebar Toggle
function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');
    const toggleBtn = document.getElementById('sidebar-toggle');
    const navLinks = document.querySelectorAll('#sidebar .nav-link[data-section]');
    const deptLinks = document.querySelectorAll('#sidebar .submenu-list .nav-link[data-dept]');

    toggleBtn.addEventListener('click', () => {
        if (window.innerWidth < 768) {
            // mobile: slide sidebar in/out
            sidebar.classList.toggle('show');
        } else {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        }
    });

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            switchSection(section);
            
            // Update active link
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            // collapse/hide sidebar on mobile or desktop
            if (window.innerWidth < 768) {
                sidebar.classList.remove('show');
            } else {
                sidebar.classList.add('collapsed');
                mainContent.classList.add('expanded');
            }
        });
    });

    deptLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const dept = link.getAttribute('data-dept');
            
            // Update state and UI
            currentDepartment = dept;
            document.getElementById('current-dept-display').innerText = dept;
            updateGreetingSubtitle();
            
            // Ensure we are on dashboard to see the changes
            switchSection('dashboard');
            
            updateStats();
            renderTable();
            renderDepartmentInfo();
            renderAssignmentTable();
            updateCharts();
            
            // Close sidebar on mobile or desktop if open
            if (window.innerWidth < 768) {
                sidebar.classList.remove('show');
            } else {
                sidebar.classList.add('collapsed');
                mainContent.classList.add('expanded');
            }
        });
    });
}

function switchSection(sectionId) {
    const sections = [
        'dashboard-section', 
        'complaints-section', 
        'officers-section', 
        'departments-section',
        'tasks-section', 
        'analytics-section', 
        'reports-section', 
        'settings-section'
    ];
    
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.add('d-none');
    });

    const targetId = `${sectionId}-section`;
    const target = document.getElementById(targetId);
    
    if (target) {
        target.classList.remove('d-none');
        
        // Specific rendering based on section
        if (sectionId === 'dashboard') {
            renderRecentComplaintsMini();
            updateStats();
            updateCharts();
        } else if (sectionId === 'complaints') {
            renderTable();
        } else if (sectionId === 'officers') {
            renderOfficersTable();
            renderWorkload();
        } else if (sectionId === 'departments') {
            renderDepartmentsTable();
        } else if (sectionId === 'tasks') {
            renderAssignmentTable();
        } else if (sectionId === 'analytics') {
            renderDetailedAnalytics();
        } else if (sectionId === 'departments') {
            renderDepartmentsTable();
        }
    }

    // Scroll to top
    window.scrollTo(0, 0);
}

// Render Recent Complaints for Mini Dashboard
function renderRecentComplaintsMini() {
    const tbody = document.getElementById('recent-complaints-mini');
    if (!tbody) return;
    
    const filtered = complaintsData
        .filter(c => currentDepartment === 'All Departments' || c.dept === currentDepartment)
        .slice(0, 5);
        
    tbody.innerHTML = filtered.map(c => `
        <tr>
            <td><span class="fw-bold">#${c.id}</span></td>
            <td>${c.title}</td>
            <td><span class="badge bg-${getStatusColor(c.status)}">${c.status}</span></td>
            <td class="small text-muted">${c.date}</td>
        </tr>
    `).join('');
}

// Render Tasks
function renderTasks() {
    const select = document.getElementById('task-assignee-select');
    if (select) {
        select.innerHTML = officersData.map(o => `<option value="${o.id}">${o.name}</option>`).join('');
    }
}

// Detailed Analytics Charts
let detailedDeptChart = null;
let detailedStatusChart = null;
let detailedTrendChart = null;
let deptResolutionChart = null;

function renderDetailedAnalytics() {
    const ctxDept = document.getElementById('detailedDeptChart');
    const ctxStatus = document.getElementById('detailedStatusChart');
    const ctxTrend = document.getElementById('detailedTrendChart');
    const ctxRes = document.getElementById('deptResolutionChart');
    
    if (!ctxDept || !ctxStatus || !ctxTrend || !ctxRes) return;

    if (detailedDeptChart) detailedDeptChart.destroy();
    if (detailedStatusChart) detailedStatusChart.destroy();
    if (detailedTrendChart) detailedTrendChart.destroy();
    if (deptResolutionChart) deptResolutionChart.destroy();

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const textColor = isDark ? '#e0e0e0' : '#666';

    const depts = departments.filter(d => d !== "All Departments");
    
    // Dept Chart
    detailedDeptChart = new Chart(ctxDept, {
        type: 'pie',
        data: {
            labels: depts,
            datasets: [{
                data: depts.map(d => complaintsData.filter(c => c.dept === d).length),
                backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'],
                borderWidth: 0
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right', labels: { color: textColor } } } }
    });

    // Status Chart
    detailedStatusChart = new Chart(ctxStatus, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'In Progress', 'Resolved'],
            datasets: [{
                data: [
                    complaintsData.filter(c => c.status === 'Pending').length,
                    complaintsData.filter(c => c.status === 'In Progress').length,
                    complaintsData.filter(c => c.status === 'Resolved').length
                ],
                backgroundColor: ['#6b7280', '#3b82f6', '#10b981'],
                borderWidth: 0
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: textColor } } } }
    });

    // Trend Chart
    detailedTrendChart = new Chart(ctxTrend, {
        type: 'line',
        data: getTrendChartData(),
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { color: textColor } }, y: { ticks: { color: textColor } } } }
    });

    // Resolution Rate
    const resolutionRates = depts.map(d => {
        const deptC = complaintsData.filter(c => c.dept === d);
        if(deptC.length === 0) return 0;
        return (deptC.filter(c => c.status === 'Resolved').length / deptC.length) * 100;
    });

    deptResolutionChart = new Chart(ctxRes, {
        type: 'bar',
        data: {
            labels: depts,
            datasets: [{ label: 'Resolution Rate (%)', data: resolutionRates, backgroundColor: '#8b5cf6', borderRadius: 4 }]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, max: 100, ticks: { color: textColor } }, x: { ticks: { color: textColor } } }, plugins: { legend: { display: false } } }
    });
}

window.switchSection = switchSection;

// Department Selector
function initDepartmentSelector() {
    const selector = document.getElementById('dept-selector');
    departments.forEach(dept => {
        const option = document.createElement('li');
        option.innerHTML = `<a class="dropdown-item" href="#" data-dept="${dept}">${dept}</a>`;
        option.addEventListener('click', (e) => {
            e.preventDefault();
            currentDepartment = dept;
            document.getElementById('current-dept-display').innerText = dept;
            updateGreetingSubtitle();
            updateStats();
            renderTable();            renderDepartmentInfo();
            renderAssignmentTable();            updateCharts();
        });
        selector.appendChild(option);
    });
}

// Notifications
function initNotifications() {
    const container = document.getElementById('notification-list');
    const badge = document.getElementById('notification-badge');
    badge.innerText = notifications.length;

    notifications.forEach(note => {
        const item = document.createElement('div');
        item.className = 'notification-item';
        item.innerHTML = `
            <div class="d-flex align-items-center">
                <div class="bg-${note.color} text-white rounded-circle p-2 me-3">
                    <i class="bi bi-${note.icon}"></i>
                </div>
                <div>
                    <p class="mb-0 small fw-bold">${note.text}</p>
                    <span class="text-muted smaller">${note.time}</span>
                </div>
            </div>
        `;
        container.appendChild(item);
    });
}

// Officer Management Logic
function renderOfficersTable() {
    const tbody = document.getElementById('officers-table-body');
    tbody.innerHTML = '';

    officersData.forEach(o => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><span class="fw-bold">${o.id}</span></td>
            <td>${o.name}</td>
            <td><span class="badge bg-${o.status === 'Active' ? 'success' : 'danger'}">${o.status}</span></td>
            <td>${o.dept}</td>
            <td>
                <div class="btn-group">
                    <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></button>
                    <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                    <button class="btn btn-sm btn-outline-primary" onclick="openAssignModal('${o.id}')"><i class="bi bi-person-plus"></i></button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function initOfficerFilter() {
    const filter = document.getElementById('officer-filter');
    filter.innerHTML = '<option value="All">All Officers</option>';
    officersData.forEach(o => {
        const opt = document.createElement('option');
        opt.value = o.name;
        opt.innerText = o.name;
        filter.appendChild(opt);
    });
}

function renderWorkload() {
    const container = document.getElementById('workload-container');
    if (!container) return;
    container.innerHTML = '';
    
    officersData.forEach(o => {
        const maxWorkload = 5;
        const percentage = (o.active / maxWorkload) * 100;
        const color = percentage > 80 ? 'danger' : percentage > 50 ? 'warning' : 'primary';
        
        container.innerHTML += `
            <div class="mb-3">
                <div class="d-flex justify-content-between mb-1">
                    <span class="small fw-bold">${o.name}</span>
                    <span class="small text-muted">${o.active} active complaints</span>
                </div>
                <div class="progress" style="height: 8px;">
                    <div class="progress-bar bg-${color}" style="width: ${percentage}%"></div>
                </div>
            </div>
        `;
    });
}

function renderActivityLog() {
    const container = document.getElementById('activity-log-container');
    container.innerHTML = '';
    
    activityLog.forEach(log => {
        container.innerHTML += `
            <div class="d-flex mb-3 border-bottom pb-2">
                <div class="me-3">
                    <div class="bg-light rounded p-2"><i class="bi bi-info-circle text-primary"></i></div>
                </div>
                <div>
                    <p class="mb-0 small">${log.text}</p>
                    <span class="smaller text-muted">${log.time}</span>
                </div>
            </div>
        `;
    });
}

// show department officers and their contact info
function renderDepartmentInfo() {
    const container = document.getElementById('department-info');
    if (!container) return;
    if (currentDepartment === 'All Departments') {
        container.innerHTML = '';
        return;
    }
    const officers = officersData.filter(o => o.dept === currentDepartment);
    if (officers.length === 0) {
        container.innerHTML = '<p class="text-muted small">No officers in this department.</p>';
        return;
    }
    container.innerHTML = `<h6 class="fw-bold mb-2">Officers in ${currentDepartment}</h6>
        <div class="list-group">
            ${officers.map(o => `<div class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <strong>${o.name}</strong><br>
                    <small>${o.contact || 'N/A'}</small>
                </div>
                <button class="btn btn-sm btn-outline-primary" onclick="openOfficerProfile('${o.id}')">View</button>
            </div>`).join('')}
        </div>`;
}

// assignment table for tasks section
function renderAssignmentTable() {
    const tbody = document.getElementById('assignment-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    const unassigned = complaintsData.filter(c => {
        return !c.officer || c.officer.trim() === '';
    });

    unassigned.forEach(c => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><span class="fw-bold text-primary">${c.id}</span></td>
            <td>${c.title}</td>
            <td>${c.dept}</td>
            <td><span class="badge bg-${getPriorityColor(c.priority)}">${c.priority}</span></td>
            <td><span class="badge bg-${getStatusColor(c.status)}">${c.status}</span></td>
            <td>${c.date}</td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="openAssignModal('${c.id}')">
                    <i class="bi bi-person-plus"></i> Assign
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });

    if (unassigned.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No unassigned complaints.</td></tr>';
    }
}

// Modal Handlers
function openOfficerProfile(id) {
    const officer = officersData.find(o => o.id === id);
    const officerComplaints = complaintsData.filter(c => c.officer === officer.name);
    
    const content = document.getElementById('officer-profile-content');
    content.innerHTML = `
        <div class="row g-4">
            <div class="col-md-4 text-center border-end">
                <img src="https://ui-avatars.com/api/?name=${officer.name}&background=0d6efd&color=fff&size=128" class="rounded-circle mb-3 shadow-sm">
                <h5 class="fw-bold">${officer.name}</h5>
                <p class="text-muted">${officer.dept}</p>
                <div class="badge bg-success mb-3">${officer.status}</div>
                <div class="h4 fw-bold text-primary">${officer.score}%</div>
                <div class="small text-muted">Performance Score</div>
            </div>
            <div class="col-md-8">
                <div class="row text-center mb-4">
                    <div class="col-4">
                        <div class="h3 fw-bold mb-0">${officer.active + officer.resolved}</div>
                        <div class="small text-muted">Total Handled</div>
                    </div>
                    <div class="col-4">
                        <div class="h3 fw-bold mb-0 text-success">${officer.resolved}</div>
                        <div class="small text-muted">Resolved</div>
                    </div>
                    <div class="col-4">
                        <div class="h3 fw-bold mb-0 text-warning">${officer.active}</div>
                        <div class="small text-muted">Pending</div>
                    </div>
                </div>
                <h6 class="fw-bold mb-3">Currently Assigned Complaints</h6>
                <div class="list-group list-group-flush">
                    ${officerComplaints.map(c => `
                        <div class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <div>
                                <div class="fw-bold small">${c.id} - ${c.title}</div>
                                <div class="smaller text-muted">${c.date}</div>
                            </div>
                            <span class="badge bg-${getStatusColor(c.status)}">${c.status}</span>
                        </div>
                    `).join('') || '<p class="text-muted small">No active complaints.</p>'}
                </div>
            </div>
        </div>
    `;
    
    new bootstrap.Modal(document.getElementById('officerProfileModal')).show();
}

function openAssignModal(officerId) {
    const officer = officersData.find(o => o.id === officerId);
    document.getElementById('assign-officer-id').value = officer.id;
    document.getElementById('assign-officer-name').value = officer.name;
    
    // Populate unassigned complaints (mock: just any pending ones)
    const select = document.getElementById('assign-complaint-id');
    select.innerHTML = '';
    complaintsData.filter(c => !c.officer || c.officer.trim() === '').forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.id;
        opt.innerText = `${c.id} - ${c.title}`;
        select.appendChild(opt);
    });
    
    new bootstrap.Modal(document.getElementById('assignComplaintModal')).show();
}

// called when assign button is clicked from complaints list
function openAssignFromComplaint(complaintId) {
    const complaint = complaintsData.find(c => c.id === complaintId);
    if (!complaint) return;
    document.getElementById('assign-complaint-fixed-id').value = complaint.id;
    document.getElementById('assign-complaint-fixed-title').value = `${complaint.id} - ${complaint.title}`;
    
    const officerSelect = document.getElementById('assign-officer-select');
    officerSelect.innerHTML = '';
    officersData.forEach(o => {
        const opt = document.createElement('option');
        opt.value = o.name;
        opt.innerText = o.name;
        officerSelect.appendChild(opt);
    });
    
    new bootstrap.Modal(document.getElementById('assignFromComplaintModal')).show();
}

function openReassignModal(complaintId) {
    const complaint = complaintsData.find(c => c.id === complaintId);
    document.getElementById('reassign-complaint-id').value = complaint.id;
    document.getElementById('reassign-complaint-title').value = complaint.title;
    document.getElementById('reassign-current-officer').value = complaint.officer;
    
    const select = document.getElementById('reassign-new-officer');
    select.innerHTML = '';
    officersData.filter(o => o.name !== complaint.officer).forEach(o => {
        const opt = document.createElement('option');
        opt.value = o.name;
        opt.innerText = o.name;
        select.appendChild(opt);
    });
    
    new bootstrap.Modal(document.getElementById('reassignModal')).show();
}

function initModalHandlers() {
    document.getElementById('assign-complaint-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const complaintId = document.getElementById('assign-complaint-id').value;
        const officerName = document.getElementById('assign-officer-name').value;
        
        const complaint = complaintsData.find(c => c.id === complaintId);
        if (complaint) {
            fetch(`http://localhost:5000/api/complaints/${complaintId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ officer: officerName, status: 'In Progress' })
            }).then(res => res.json()).then(data => {
                const index = complaintsData.findIndex(c => c.id === complaintId);
                if (index !== -1) complaintsData[index] = data;
                
                // Log activity
                activityLog.unshift({ text: `Officer ${officerName} assigned to ${complaintId}`, time: "Just now" });
                
                // Update UI
                bootstrap.Modal.getInstance(document.getElementById('assignComplaintModal')).hide();
                renderTable();
                renderWorkload();
                renderActivityLog();
                updateStats();
                renderAssignmentTable();
            });
        }
    });

    document.getElementById('assign-fromcomplaint-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const complaintId = document.getElementById('assign-complaint-fixed-id').value;
        const officerName = document.getElementById('assign-officer-select').value;
        const complaint = complaintsData.find(c => c.id === complaintId);
        if (complaint) {
            fetch(`http://localhost:5000/api/complaints/${complaintId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ officer: officerName, status: 'In Progress' })
            }).then(res => res.json()).then(data => {
                const index = complaintsData.findIndex(c => c.id === complaintId);
                if (index !== -1) complaintsData[index] = data;
                activityLog.unshift({ text: `Officer ${officerName} assigned to ${complaintId}`, time: "Just now" });
                bootstrap.Modal.getInstance(document.getElementById('assignFromComplaintModal')).hide();
                renderTable();
                renderWorkload();
                renderActivityLog();
                updateStats();
                renderAssignmentTable();
            });
        }
    });

    // department form handler
    const deptForm = document.getElementById('department-form');
    if (deptForm) {
        deptForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const nameInput = document.getElementById('dept-name-input');
            const name = nameInput.value.trim();
            if (name && !departments.includes(name)) {
                departments.push(name);
                // also add to complaints/officers? no
                renderDepartmentsTable();
                initDepartmentSelector();
            }
            bootstrap.Modal.getInstance(document.getElementById('addDepartmentModal')).hide();
            nameInput.value = '';
        });
    }

    document.getElementById('reassign-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const complaintId = document.getElementById('reassign-complaint-id').value;
        const newOfficer = document.getElementById('reassign-new-officer').value;
        
        const complaint = complaintsData.find(c => c.id === complaintId);
        if (complaint) {
            const oldOfficer = complaint.officer;
            fetch(`http://localhost:5000/api/complaints/${complaintId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ officer: newOfficer })
            }).then(res => res.json()).then(data => {
                const index = complaintsData.findIndex(c => c.id === complaintId);
                if (index !== -1) complaintsData[index] = data;
                
                // Log activity
                activityLog.unshift({ text: `Admin reassigned ${complaintId} from ${oldOfficer} to ${newOfficer}`, time: "Just now" });
                
                // Update UI
                bootstrap.Modal.getInstance(document.getElementById('reassignModal')).show();
                renderTable();
                renderWorkload();
                renderActivityLog();
                bootstrap.Modal.getInstance(document.getElementById('reassignModal')).hide();
            });
        }
    });
}

function toggleOfficerStatus(id) {
    const officer = officersData.find(o => o.id === id);
    if (officer) {
        officer.status = officer.status === 'Active' ? 'Inactive' : 'Active';
        renderOfficersTable();
    }
}

// Table Rendering
function renderTable() {
    const tbody = document.getElementById('complaints-table-body');
    tbody.innerHTML = '';

    const filtered = complaintsData.filter(c => {
        const matchesDept = currentDepartment === "All Departments" || c.dept === currentDepartment;
        const matchesSearch = c.title.toLowerCase().includes(searchTerm) || c.id.toLowerCase().includes(searchTerm);
        const matchesStatus = statusFilter === "All" || c.status === statusFilter;
        const matchesPriority = priorityFilter === "All" || c.priority === priorityFilter;
        const matchesOfficer = officerFilter === "All" || c.officer === officerFilter;
        return matchesDept && matchesSearch && matchesStatus && matchesPriority && matchesOfficer;
    });

    filtered.forEach(c => {
        const row = document.createElement('tr');
        const assigned = c.officer && c.officer.trim().length > 0;
        row.innerHTML = `
            <td><span class="fw-bold text-primary">${c.id}</span></td>
            <td>
                ${c.title}
                ${c.evidence ? `<br><a href="http://localhost:5000/${c.evidence}" target="_blank" class="small text-decoration-none"><i class="bi bi-paperclip"></i> View Evidence</a>` : ''}
            </td>
            <td>${c.dept}</td>
            <td><span class="badge bg-${getPriorityColor(c.priority)}">${c.priority}</span></td>
            <td><span class="badge bg-${getStatusColor(c.status)}">${c.status}</span></td>
            <td>${assigned ? c.officer : '<span class="text-muted">Unassigned</span>'}</td>
            <td>${c.date}</td>
            <td>
                ${assigned ?
                    `<button class="btn btn-sm btn-outline-warning" onclick="openReassignModal('${c.id}')">
                        <i class="bi bi-person-gear"></i> Reassign
                    </button>` :
                    `<button class="btn btn-sm btn-outline-primary" onclick="openAssignFromComplaint('${c.id}')">
                        <i class="bi bi-person-plus"></i> Assign
                    </button>`
                }
            </td>
        `;
        tbody.appendChild(row);
    });

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">No complaints found matching the criteria.</td></tr>';
    }
}

function getPriorityColor(p) {
    switch(p) {
        case 'High': return 'danger';
        case 'Medium': return 'warning';
        case 'Low': return 'info';
        default: return 'secondary';
    }
}

function getStatusColor(s) {
    switch(s) {
        case 'Pending': return 'secondary';
        case 'In Progress': return 'primary';
        case 'Resolved': return 'success';
        default: return 'dark';
    }
}

// Charts Initialization
function initCharts() {
    const ctxStatus = document.getElementById('statusChart');
    const ctxPriority = document.getElementById('priorityChart');
    const ctxTrend = document.getElementById('trendChart');
    const ctxPerf = document.getElementById('officerPerformanceChart');

    if (ctxStatus) {
        charts.status = new Chart(ctxStatus.getContext('2d'), {
            type: 'bar',
            data: getStatusChartData(),
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    if (ctxPriority) {
        charts.priority = new Chart(ctxPriority.getContext('2d'), {
            type: 'pie',
            data: getPriorityChartData(),
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    if (ctxTrend) {
        charts.trend = new Chart(ctxTrend.getContext('2d'), {
            type: 'line',
            data: getTrendChartData(),
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    if (ctxPerf) {
        charts.performance = new Chart(ctxPerf.getContext('2d'), {
            type: 'bar',
            data: getPerformanceChartData(),
            options: { responsive: true, maintainAspectRatio: false }
        });
    }
}

function updateCharts() {
    if (charts.status) {
        charts.status.data = getStatusChartData();
        charts.status.update();
    }
    if (charts.priority) {
        charts.priority.data = getPriorityChartData();
        charts.priority.update();
    }
    if (charts.trend) {
        // respect filter selection
        updateTrendChart();
    }
    if (charts.performance) {
        charts.performance.data = getPerformanceChartData();
        charts.performance.update();
    }
}

function getPerformanceChartData() {
    return {
        labels: officersData.map(o => o.name),
        datasets: [{
            label: 'Resolved Complaints',
            data: officersData.map(o => o.resolved),
            backgroundColor: '#198754'
        }]
    };
}

function getStatusChartData() {
    const filtered = complaintsData.filter(c => currentDepartment === "All Departments" || c.dept === currentDepartment);
    const counts = { Pending: 0, "In Progress": 0, Resolved: 0 };
    filtered.forEach(c => counts[c.status]++);

    return {
        labels: Object.keys(counts),
        datasets: [{
            label: 'Complaints by Status',
            data: Object.values(counts),
            backgroundColor: ['#6c757d', '#0d6efd', '#198754']
        }]
    };
}

function getPriorityChartData() {
    const filtered = complaintsData.filter(c => currentDepartment === "All Departments" || c.dept === currentDepartment);
    const counts = { High: 0, Medium: 0, Low: 0 };
    filtered.forEach(c => counts[c.priority]++);

    return {
        labels: Object.keys(counts),
        datasets: [{
            data: Object.values(counts),
            backgroundColor: ['#dc3545', '#ffc107', '#0dcaf0']
        }]
    };
}

function getTrendChartData() {
    // Mock monthly trend
    return {
        labels: ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
        datasets: [{
            label: 'New Complaints',
            data: [12, 19, 15, 25, 22, 30],
            borderColor: '#0d6efd',
            tension: 0.4,
            fill: true,
            backgroundColor: 'rgba(13, 110, 253, 0.1)'
        }]
    };
}

// Global function for theme.js to call
window.updateChartsTheme = (theme) => {
    const color = theme === 'dark' ? '#e0e0e0' : '#666';
    const gridColor = theme === 'dark' ? '#333' : '#eee';

    Object.values(charts).forEach(chart => {
        if (chart.options.scales) {
            if (chart.options.scales.x) {
                chart.options.scales.x.ticks.color = color;
                chart.options.scales.x.grid.color = gridColor;
            }
            if (chart.options.scales.y) {
                chart.options.scales.y.ticks.color = color;
                chart.options.scales.y.grid.color = gridColor;
            }
        }
        if (chart.options.plugins && chart.options.plugins.legend) {
            chart.options.plugins.legend.labels.color = color;
        }
        chart.update();
    });
};

function updateStats() {
    const filtered = complaintsData.filter(c => currentDepartment === "All Departments" || c.dept === currentDepartment);
    
    // update subtitle when stats refresh
    updateGreetingSubtitle();
    const total = filtered.length;
    const pending = filtered.filter(c => c.status === 'Pending').length;
    const resolved = filtered.filter(c => c.status === 'Resolved').length;
    const assigned = filtered.filter(c => c.officer && c.officer.trim() !== '').length;
    const unassigned = filtered.filter(c => !c.officer || c.officer.trim() === '').length;

    const elTotal = document.getElementById('total-complaints');
    if (elTotal) elTotal.innerText = total;
    
    const elPending = document.getElementById('pending-complaints');
    if (elPending) elPending.innerText = pending;
    
    const elResolved = document.getElementById('resolved-complaints');
    if (elResolved) elResolved.innerText = resolved;
    
    const elAssigned = document.getElementById('assigned-complaints');
    if (elAssigned) elAssigned.innerText = assigned;
    
    const unassignedEl = document.getElementById('unassigned-complaints');
    if (unassignedEl) unassignedEl.innerText = unassigned;
}

// adjust greeting subtitle based on selected department
function updateGreetingSubtitle() {
    const sub = document.getElementById('greeting-subtitle');
    if (!sub) return;
    if (currentDepartment && currentDepartment !== 'All Departments') {
        sub.innerText = `Overview for ${currentDepartment}`;
    } else {
        sub.innerText = 'What do you want to manage today?';
    }
}

// New Dashboard functions
function renderDepartmentsTable() {
    const tbody = document.getElementById('departments-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    const depts = departments.filter(d => d !== "All Departments");
    depts.forEach(dept => {
        const deptComplaints = complaintsData.filter(c => c.dept === dept).length;
        const deptOfficers = officersData.filter(o => o.dept === dept).length;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><span class="fw-bold">${dept}</span></td>
            <td>${deptComplaints}</td>
            <td>${deptOfficers}</td>
            <td>
                <button class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i> Edit</button>
                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Delete</button>
            </td>
        `;
        row.style.cursor = 'pointer';
        row.addEventListener('click', () => {
            currentDepartment = dept;
            document.getElementById('current-dept-display').innerText = dept;
            updateGreetingSubtitle();
            switchSection('dashboard');
            updateStats();
            renderTable();
            renderDepartmentInfo();
            renderAssignmentTable();
            updateCharts();
        });
        tbody.appendChild(row);
    });
}

function updateTrendChart() {
    const filter = document.getElementById('trend-time-filter').value;
    if (charts.trend) {
        if (filter === 'Weekly') {
            charts.trend.data.labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
            charts.trend.data.datasets[0].data = [5, 8, 3, 10, 7, 2, 4];
        } else if (filter === 'Monthly') {
            charts.trend.data.labels = ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
            charts.trend.data.datasets[0].data = [12, 19, 15, 25, 22, 30];
        } else if (filter === 'Yearly') {
            charts.trend.data.labels = ['2023', '2024', '2025', '2026'];
            charts.trend.data.datasets[0].data = [120, 180, 210, 250];
        }
        charts.trend.update();
    }
}

